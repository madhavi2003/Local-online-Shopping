
    let form = document.getElementById("form");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      validate();
    });
    function validate() {
      let fname = document.getElementById("fname").value.trim();
      let sname = document.getElementById("sname").value.trim();
      let pwd = document.getElementById("password").value.trim();
      let cpwd = document.getElementById("cpass").value.trim();
      let email = document.getElementById("email").value.trim();
      let is_fname_valid = true;
      let is_sname_valid = true;
      let is_email_valid=true;
      let is_pwd_valid = true;
      if (fname == "") {
        document.getElementById("errorMessage").innerText =
          "First name cannot be empty";
          is_fname_valid =false;
        return;
      }
      if (/\d/.test(fname)) {
        document.getElementById("errorMessage").innerText =
          "First name cannot contain Digits";
        is_name_valid = false;
        return;
      }
      if (fname.length < 3) {
        document.getElementById("errorMessage").innerText =
          "First name cannot be lessthan 3 Characters";
        is_name_valid = false;
        return;
      }
      if (sname == "") {
        document.getElementById("errorMessage").innerText =
          "Second name cannot be empty";
        return;
      }
      if (/\d/.test(sname)) {
        document.getElementById("errorMessage").innerText =
          "Second name cannot contain Digits";
        is_name_valid = false;
        return;
      }
      if (sname.length < 3) {
        document.getElementById("errorMessage").innerText =
          "Second name cannot be lessthan 3 Characters";
        is_name_valid = false;
        return;
      }
      if(email==""){
        document.getElementById("errorMessage").innerText="Email should not empty";
        is_email_valid=false;
        return;
      }
      if(!email.match(/^(([a-zA-Z]+[0-9\._-]*))+@(([a-zA-Z]+[\._-]*)+).([a-zA-Z]+)$/)){
        document.getElementById("errorMessage").innerText="Enter valid email id";
        is_email_valid=False;
        return;
      }
      if (pwd == "") {
        document.getElementById("errorMessage").innerText =
          "Password cannot be empty";
        is_pwd_valid = false;
        return;
      }
      if (pwd.length < 8) {
        document.getElementById("errorMessage").innerText =
          "Password cannot be lessthan 8 Characters";
        is_pwd_valid = false;
        return;
      }
      if (!/[a-z]+/.test(pwd)) {
        document.getElementById("errorMessage").innerText =
          "Password must contain one lowercase letter";
        is_pwd_valid = false;
        return;
      }
      if (!/[A-Z]+/.test(pwd)) {
        document.getElementById("errorMessage").innerText =
          "Password must contain one uppercase letter";
        is_pwd_valid = false;
        return;
      }
      if (!/[@#&-]+/.test(pwd)) {
        document.getElementById("errorMessage").innerText =
          "Password must contain one Special Character";
        is_pwd_valid = false;
        return;
      }
      if (pwd != cpwd) {
        document.getElementById("errorMessage").innerText =
          "Password confirmation mismatch";
        is_pwd_valid = false;
        return;
      }
      if (!is_checked) {
        document.getElementById("errorMessage").innerText =
          "Please Agree Terms and Contions to Log-in";
        return;
      }
      if (is_name_valid && is_email_valid && is_pwd_valid && is_checked&&is_mobile_valid) {
        form.submit();
      }
    }
 